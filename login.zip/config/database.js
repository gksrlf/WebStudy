module.exports = {
	host: "localhost",
	user: "root",
	password: "gksrlf78",
	database: "mysql",
}
