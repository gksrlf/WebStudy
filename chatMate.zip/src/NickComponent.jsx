import React from "react"
import "bootstrap/dist/css/bootstrap.css"
import Zoom, { Fade } from "react-reveal"

class NickComponent extends React.Component {}
