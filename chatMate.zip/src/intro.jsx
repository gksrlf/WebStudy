import React from "react"
import "bootstrap/dist/css/bootstrap.css"
import Zoom, { Fade } from "react-reveal"

class Intro extends React.Component {
	render() {
		return <Fade top>ChatMate</Fade>
	}
}

export default Intro
